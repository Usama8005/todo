﻿using System.ComponentModel.DataAnnotations;

namespace TODO_LIST_PROJECT.Models
{
    public class EditTaskViewModel
    {
      
            public int Id { get; set; } 

            [Required(ErrorMessage = "Title is required")]
            public string MissionTitle { get; set; }

            public string Details { get; set; }

            [Required]
            public DateTime ScheduleDate { get; set; }

            public string Category { get; set; }
        }
    }