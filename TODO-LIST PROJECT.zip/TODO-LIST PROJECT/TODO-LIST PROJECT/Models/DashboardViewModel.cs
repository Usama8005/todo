﻿using System;
using System.Collections.Generic;

namespace ToDoListProject.Models
{
  
    public class ToDoTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string FromWho { get; set; } // Sirf Family aur FYP ke liye
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }
        public string Category { get; set; } // "SELF", "FAMILY", "FYP"
    }

    // Dashboard ke liye main ViewModel
    public class DashboardViewModel
    {
        public List<ToDoTask> SelfTasks { get; set; }
        public List<ToDoTask> FamilyTasks { get; set; }
        public List<ToDoTask> FypTasks { get; set; }

        public DashboardViewModel()
        {
            SelfTasks = new List<ToDoTask>();
            FamilyTasks = new List<ToDoTask>();
            FypTasks = new List<ToDoTask>();
        }
    }
}
