﻿namespace TODO_LIST_PROJECT.Models
{
    public class NotificationViewModel
    {
        public class NotificationItem
        {
            public string SenderName { get; set; }
            public string Message { get; set; }
            public string TimeAgo { get; set; }
            public string Type { get; set; }
            public string ImageUrl { get; set; } // Image path ke liye
        }


        public List<NotificationItem> Notifications { get; set; }
    }
}

