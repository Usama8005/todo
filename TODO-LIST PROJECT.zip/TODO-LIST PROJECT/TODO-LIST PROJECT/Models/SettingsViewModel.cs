﻿namespace TODO_LIST_PROJECT.Models
{
    public class SettingsViewModel
    {
        public string UserName { get; set; }


        public string SnoozeTime { get; set; } = "DEFAULT";
        public bool IsNotificationEnabled { get; set; } = true;
        public bool IsDarkMode { get; set; } = false;
    }

}
