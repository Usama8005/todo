﻿using System.ComponentModel.DataAnnotations;

namespace TODO_LIST_PROJECT.Models
{
    public class TaskModel
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime TaskDate { get; set; }

        public string TaskFor { get; set; } // Dropdown value ke liye
    }
}
