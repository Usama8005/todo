﻿using System.ComponentModel.DataAnnotations;

namespace TODO_LIST_PROJECT.Models
{
    public class MemberTaskViewModel
    {
   
        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        [Required]
        public string Name { get; set; }

        // Task Fields
        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        [Required]
        public DateTime TaskDate { get; set; }

        public string TaskCategory { get; set; }
    }
}
   
