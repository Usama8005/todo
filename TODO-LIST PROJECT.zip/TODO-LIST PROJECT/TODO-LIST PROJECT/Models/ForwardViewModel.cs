﻿namespace TODO_LIST_PROJECT.Models
{
        public class ForwardOption
        {
            public string Name { get; set; }
            public bool IsSelected { get; set; }
        }

        public class ForwardViewModel
        {
            public List<ForwardOption> Options { get; set; }
        }
    }

