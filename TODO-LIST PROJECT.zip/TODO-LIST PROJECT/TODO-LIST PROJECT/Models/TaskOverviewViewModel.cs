﻿namespace TODO_LIST_PROJECT.Models
{
    public class TaskOverviewViewModel
    {
        public string Description { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
    }
}
