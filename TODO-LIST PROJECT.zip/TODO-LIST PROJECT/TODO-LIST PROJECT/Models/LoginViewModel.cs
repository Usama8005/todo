﻿using System.ComponentModel.DataAnnotations;

namespace TODO_LIST_PROJECT.Models
{
    public class LoginViewModel
    
        {
            [Required(ErrorMessage = "Email is required")]
            [EmailAddress(ErrorMessage = "Invalid Email Address")]
            public string Email { get; set; }

            [Required(ErrorMessage = "Password is required")]
            [DataType(DataType.Password)]
            public string Password { get; set; }
        }
    }

