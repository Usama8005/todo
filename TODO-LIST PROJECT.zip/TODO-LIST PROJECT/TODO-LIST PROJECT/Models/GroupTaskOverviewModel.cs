﻿namespace TODO_LIST_PROJECT.Models
{
    public class GroupTaskOverviewModel
    {
        public string GroupName { get; set; } = "Family Group";
        public string TaskDescription { get; set; } = "PICKUP YOUGURT AT YOUR OFF TIME";
        public string Sender { get; set; } = "Mom";
        public string Receiver { get; set; } = "Me";
        public string TaskDate { get; set; } = "FEB 20, 2026";
    }

}
