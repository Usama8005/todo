﻿using System.ComponentModel.DataAnnotations;

namespace TODO_LIST_PROJECT.Models
{
    public class GroupModel
    {
        [Required(ErrorMessage = "Group name is required")]
        public string GroupName { get; set; }


        public List<string> SelectedMembers { get; set; } = new List<string>();

        public List<string> AvailableMembers { get; set; } = new List<string>
        {
            "Mom", "Dad", "Brother", "MySelf", "Friend", "Manan"
        };
    }
}

