﻿namespace TODO_LIST_PROJECT.Models
{
    public class TaskReminderViewModel
    {
        public string From { get; set; }
        public string Title { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }
    }
}
