﻿using Microsoft.AspNetCore.Mvc;
using TODO_LIST_PROJECT.Models;
using ToDoListProject.Models;
using static TODO_LIST_PROJECT.Models.NotificationViewModel;



namespace TODO_LIST_PROJECT.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction("Dashboard", "Account");
            }


            return View(model);
        }


        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Signup(SignupViewModel model)
        {

            if (ModelState.IsValid)
            {

                return RedirectToAction("Login", "Account");
            }

            return View(model);
        }

        public IActionResult Dashboard()
        {

            var allTasks = new List<ToDoTask>
            {
                new ToDoTask { Id = 1, Title = "PROJECT MEETING", DueDate = new DateTime(2026, 2, 17, 2, 30, 0), IsCompleted = false, Category = "SELF", FromWho = "" },
                new ToDoTask { Id = 2, Title = "GYM", DueDate = new DateTime(2026, 2, 17, 5, 0, 0), IsCompleted = false, Category = "SELF", FromWho = "" },
                new ToDoTask { Id = 3, Title = "ASSIGNMENT", DueDate = new DateTime(2026, 2, 19, 2, 0, 0), IsCompleted = false, Category = "SELF", FromWho = "" },

                new ToDoTask { Id = 4, Title = "PICK-UP SIS", FromWho = "Mom", DueDate = new DateTime(2026, 2, 17, 2, 30, 0), IsCompleted = true, Category = "FAMILY" },
                new ToDoTask { Id = 5, Title = "BRING YOUGURT", FromWho = "Mom", DueDate = new DateTime(2026, 2, 17, 5, 0, 0), IsCompleted = true, Category = "FAMILY" },
                new ToDoTask { Id = 6, Title = "BUY GROCERIES", FromWho = "Mom", DueDate = new DateTime(2026, 2, 19, 2, 0, 0), IsCompleted = true, Category = "FAMILY" },

                new ToDoTask { Id = 7, Title = "PROJECT MEETING", FromWho = "Admin", DueDate = new DateTime(2026, 2, 17, 2, 30, 0), IsCompleted = true, Category = "FYP" },
                new ToDoTask { Id = 8, Title = "MEET SUPERVISOR", FromWho = "Sir Azeem", DueDate = new DateTime(2026, 2, 17, 5, 0, 0), IsCompleted = true, Category = "FYP" }
            };


            var viewModel = new DashboardViewModel
            {
                SelfTasks = allTasks.Where(t => t.Category == "SELF").ToList(),
                FamilyTasks = allTasks.Where(t => t.Category == "FAMILY").ToList(),
                FypTasks = allTasks.Where(t => t.Category == "FYP").ToList()
            };

            return View(viewModel);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Create(TaskModel task)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction("Index", "Home");
            }
            return View(task);
        }

        public IActionResult Edit(int id)
        {

            var task = new EditTaskViewModel
            {
                Id = id,
                MissionTitle = "Existing Task Title",
                Details = "Existing Description",
                ScheduleDate = DateTime.Now,
                Category = "Work Project"
            };

            return View(task);
        }

        [HttpPost]
        public IActionResult Edit(EditTaskViewModel model)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction("Dashboard", "Account");
            }
            return View(model);
        }

        public IActionResult AddMember()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddMember(MemberTaskViewModel model)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction("AddTask");
            }
            return View(model);
        }


        public IActionResult AddTask()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddGroup()
        {
            var model = new GroupModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult CreateGroup(GroupModel model)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction("Dashboard", "Account");
            }
            return View(model);
        }

        public IActionResult Forward()
        {
            var model = new ForwardViewModel
            {
                Options = new List<ForwardOption>
        {
            new ForwardOption { Name = "Mom" },
            new ForwardOption { Name = "FYP" },
            new ForwardOption { Name = "Brother" },
            new ForwardOption { Name = "MySelf" },
            new ForwardOption { Name = "Friend" },
            new ForwardOption { Name = "Manan" }
        }
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult Send(ForwardViewModel model)
        {
            // Yahan aap selected items ko handle kar saktay hain
            var selectedContacts = model.Options.Where(x => x.IsSelected).ToList();
            return RedirectToAction("Index");
        }
    
    public IActionResult GroupTaskOverview()
        {
            var model = new GroupTaskOverviewModel();
  
            return View(model);
        }
    
    public IActionResult TaskOverview()
        {
           
            var model = new TaskOverviewViewModel
            {
                Description = "PICKUP YOUGURT AT YOUR OFF TIME",
                From = "Mom",
                To = "Me",
                Date = "FEB 20, 2026",
                Time = "3:23 PM"
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult MarkAsCompleted(int taskId)
        {

            return RedirectToAction("TaskOverview");
        }
        public IActionResult Reminder()
        {
      
            var viewModel = new TaskReminderViewModel
            {
                From = "Home",
                Title = "BUY GROCERY",
                Time = "7:00 PM",
                Date = "FEB 20, 2026"
            };

            return View(viewModel);
        }


        [HttpPost]
        public IActionResult MarkAsDone(int taskId)
        {
            return RedirectToAction("Dashboard", "Account");
        }

        [HttpPost]
        public IActionResult SnoozeTask(int taskId)
        {
            return Ok();
        }
    
    public IActionResult Settings()
        {
          
            var model = new SettingsViewModel
            {
                UserName = "SYED ALI", 
                SnoozeTime = "DEFAULT",
                IsNotificationEnabled = true,
                IsDarkMode = false
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult UpdateSettings(SettingsViewModel model)
        {
            if (ModelState.IsValid)
            {
               
                return RedirectToAction("Settings");
            }
            return View("Settings", model);
        }
        public IActionResult Notification()
        {
            var model = new NotificationViewModel
            {
                Notifications = new List<NotificationItem>
        {
            new NotificationItem {
                SenderName = "MOM",
                Message = "Bring Yougurt",
                TimeAgo = "10 min ago",
                Type = "Normal",
                ImageUrl = "https://randomuser.me/api/portraits/women/44.jpg" // Sample Pakistani/Desi Look
            },
            new NotificationItem {
                SenderName = "Ali",
                Message = "Make Assignment of AA subject.",
                TimeAgo = "3 min ago",
                Type = "Normal",
                ImageUrl = "https://randomuser.me/api/portraits/men/32.jpg"
            },
            new NotificationItem {
                SenderName = "TASK EXPIRED",
                Message = "BRING YOUGURT: TASK WAS NOT COMPLETED ON TIME",
                TimeAgo = "5 min ago",
                Type = "Expired",
                ImageUrl = "https://randomuser.me/api/portraits/women/65.jpg"
            },
            new NotificationItem {
                SenderName = "Hassan",
                Message = "You Have Two Tasks at one Time.",
                TimeAgo = "5 min ago",
                Type = "Clash",
                ImageUrl = "https://randomuser.me/api/portraits/men/46.jpg"
            }
        }
            };
            return View(model);
        }
    }
}

 

